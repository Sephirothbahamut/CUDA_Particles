#pragma once
#include "cuda_runtime.h"
#include "device_launch_parameters.h"
#include <stdio.h>
#include <cstdlib>

inline void cuda_check(cudaError_t err)
	{
	if (err != cudaSuccess)
		{
		fprintf(stderr, "Cuda error: %s\n", cudaGetErrorString(err));
		exit(0);
		}
	}