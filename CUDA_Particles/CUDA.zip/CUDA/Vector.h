#pragma once
#include <vector>
#include <stdexcept>

#include <utils/compilation/debug.h>

#include "Base.h"

namespace utils::CUDA
	{
	template <typename T>
	class vector;

	template <typename T>
	class device_vector
		{
		template <typename T>
		friend class vector;
		public:

			__device__ size_t size() const noexcept { return _size; }

			__device__       T& operator[](size_t index)       noexcept { return _arr[index]; }
			__device__ const T& operator[](size_t index) const noexcept { return _arr[index]; }

			__device__ T* begin()                      { return _arr; }
			__device__ T* end()                        { return _arr + _size; }
			__device__ const T* begin() const noexcept { return _arr; }
			__device__ const T* end()   const noexcept { return _arr + _size; }
		private:
			__host__ device_vector(T* device_array, size_t size) : _arr{device_array}, _size{size} {}

			T* _arr;
			size_t _size;
		};

	template <typename T>
	class vector
		{
		public:
			// Allocates a vector in cuda memory
			vector(size_t size) : _size{size}
				{
				cuda_check(cudaMalloc((void**)&arr_ptr, size * sizeof(T)));

				cuda_check(cudaMalloc((void**)&vec_ptr, sizeof(device_vector<T>)));

				device_vector<T> tmp(arr_ptr, size);
				cuda_check(cudaMemcpy(vec_ptr, &tmp, sizeof(device_vector<T>), cudaMemcpyHostToDevice));
				}

			// Allocates a vector in cuda memory, initialized with passed CPU vector's values
			vector(const std::vector<T>& vec) : vector{vec.size()} { from(vec); }

			// Returns the address of the device vector; use to pass it to a kernel.
			device_vector<T>* get_device_ptr() noexcept { return vec_ptr; }

			void from(const std::vector<T>& vec) utils_ifdebug(noexcept)
				{
#ifndef NDEBUG
				if (vec.size() != size()) { throw std::out_of_range{"Trying to copy vector from CPU to GPU, but sizes don't match."}; }
#endif
				cuda_check(cudaMemcpy(arr_ptr, vec.data(), vec.size() * sizeof(T), cudaMemcpyHostToDevice));
				}

			void to(std::vector<T>& vec) const utils_ifdebug(noexcept)
				{
#ifndef NDEBUG
				if (vec.size() != size()) { throw std::out_of_range{"Trying to copy vector from CPU to GPU, but sizes don't match."}; }
#endif
				cuda_check(cudaMemcpy(vec.data(), arr_ptr, vec.size() * sizeof(T), cudaMemcpyDeviceToHost));
				}

			size_t size() const noexcept { return _size; }

			~vector()
				{
				if (vec_ptr) { cudaFree(vec_ptr); }
				if (arr_ptr) { cudaFree(arr_ptr); }
				}

		private:
			device_vector<T>* vec_ptr{nullptr};
			T* arr_ptr{nullptr};

			const size_t _size{0};
		};
	}