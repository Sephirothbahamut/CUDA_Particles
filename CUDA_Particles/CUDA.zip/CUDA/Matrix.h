#pragma once
#include <stdexcept>

#include <utils/containers/matrix.h>
#ifdef NDEBUG
#define utils_ifdebug(x)
#define utils_ifrelease(x) x
#else
#define utils_ifdebug(x) x
#define utils_ifrelease(x)
#endif

#include "Base.h"

namespace utils::CUDA
	{
	template <typename T, utils::matrix_memory MEMORY>
	class matrix;

	template <typename T, utils::matrix_memory MEMORY = utils::matrix_memory::width_first >
	class device_matrix
		{
		template <typename T, utils::matrix_memory MEMORY>
		friend class matrix;
		public:
			struct coords_t { size_t x{0}; size_t y{0}; };

			__device__ size_t width()  const noexcept { return _width; }
			__device__ size_t height() const noexcept { return _height; }
			__device__ size_t size()   const noexcept { return _width * _height; }

			__device__ T* data() { return _arr; }

			__device__ size_t get_index(size_t x, size_t y) const noexcept
				{
				if constexpr (MEMORY == utils::matrix_memory::width_first) { return x + (y * _width); }
				else { return y + (x * _height); }
				}
			__device__ size_t get_x(size_t index) const noexcept { if constexpr (MEMORY == utils::matrix_memory::width_first) { return index % width(); } else { return index / height(); } } //TODO test
			__device__ size_t get_y(size_t index) const noexcept { if constexpr (MEMORY == utils::matrix_memory::width_first) { return index / width(); } else { return index % height(); } } //TODO test
			__device__ coords_t get_coords(size_t index) const noexcept { return {get_x(index), get_y(index)}; }
			
			__device__ const T& operator[](size_t i)        const noexcept { return _arr[i]; }
			__device__       T& operator[](size_t i)              noexcept { return _arr[i]; }
			__device__ const T& operator[](coords_t coords) const noexcept { return _arr[get_index(coords.x, coords.y)]; }
			__device__       T& operator[](coords_t coords)       noexcept { return _arr[get_index(coords.x, coords.y)]; }

			// Arithmetic

			/*static T cross(const matrix_dyn& a, const matrix_dyn& b) noexcept { }//TODO
			static T dot(const matrix_dyn& a, const matrix_dyn& b) noexcept {}//TODO
			static T dot(const matrix_dyn& a, const matrix_dyn& b) noexcept {}//TODO*/

			__device__ const auto begin()   const noexcept { return _arr; }
			__device__       auto begin()         noexcept { return _arr; }
			__device__ const auto end()     const noexcept { return _arr + size(); }
			__device__       auto end()           noexcept { return _arr + size(); }
			/*const auto cbegin()  const noexcept { return _arr.cbegin(); }
				  auto cbegin()        noexcept { return _arr.cbegin(); }
			const auto cend()    const noexcept { return _arr.cend(); }
				  auto cend()          noexcept { return _arr.cend(); }
			const auto rbegin()  const noexcept { return _arr.rbegin(); }
				  auto rbegin()        noexcept { return _arr.rbegin(); }
			const auto rend()    const noexcept { return _arr.rend(); }
				  auto rend()          noexcept { return _arr.rend(); }
			const auto crbegin() const noexcept { return _arr.crbegin(); }
				  auto crbegin()       noexcept { return _arr.crbegin(); }
			const auto crend()   const noexcept { return _arr.crend(); }
				  auto crend()         noexcept { return _arr.crend(); }*/

		private:
			__host__ device_matrix(size_t width, size_t height, T* arr) : _width(width), _height(height), _arr(arr)
				{}

			size_t _width;
			size_t _height;
			T* _arr;
		};

	template <typename T, utils::matrix_memory MEMORY = utils::matrix_memory::width_first >
	class matrix
		{
		using device_matrix_t = device_matrix<T, MEMORY>;
		using Host_matrix_t = utils::matrix_dyn<T, MEMORY>;
		public:
			// Allocates a vector in cuda memory
			matrix(size_t width, size_t height) : _width{width}, _height{height}
				{
				cuda_check(cudaMalloc((void**)&arr_ptr, width * height * sizeof(T)));

				cuda_check(cudaMalloc((void**)&mat_ptr, sizeof(device_matrix_t)));

				device_matrix_t tmp{width, height, arr_ptr};

				cuda_check(cudaMemcpy(mat_ptr, &tmp, sizeof(device_matrix_t), cudaMemcpyHostToDevice));
				}

			// Allocates a vector in cuda memory, initialized with passed CPU vector's values
			matrix(const Host_matrix_t& mat) : matrix{mat.width(), mat.height()} { from(mat); }

			// Returns the address of the device vector; use to pass it to a kernel.
			device_matrix_t* get_device_ptr() noexcept { return mat_ptr; }

			void from(const Host_matrix_t& mat) utils_ifdebug(noexcept)
				{
#ifndef NDEBUG
				if (mat.width() != width() || mat.height() != height()) { throw std::out_of_range{"Trying to copy matrix from CPU to GPU, but sizes don't match."}; }
#endif
				cuda_check(cudaMemcpy(arr_ptr, mat.data(), mat.size() * sizeof(T), cudaMemcpyHostToDevice));
				}

			void to(Host_matrix_t& mat) const utils_ifdebug(noexcept)
				{
#ifndef NDEBUG
				if (mat.width() != width() || mat.height() != height()) { throw std::out_of_range{"Trying to copy matrix from CPU to GPU, but sizes don't match."}; }
#endif
				cuda_check(cudaMemcpy(mat.data(), arr_ptr, mat.size() * sizeof(T), cudaMemcpyDeviceToHost));
				}

			size_t size()   const noexcept { return _width * _height; }
			size_t width()  const noexcept { return _width;  }
			size_t height() const noexcept { return _height; }

			~matrix()
				{
				if (mat_ptr) { cudaFree(mat_ptr); }
				if (arr_ptr) { cudaFree(arr_ptr); }
				}

		private:
			device_matrix_t* mat_ptr{nullptr};
			T* arr_ptr{nullptr};

			const size_t _width {0};
			const size_t _height{0};
		};
	}